package phoneshop.phoneshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhoneshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
