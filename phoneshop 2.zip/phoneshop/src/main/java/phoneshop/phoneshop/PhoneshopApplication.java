package phoneshop.phoneshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhoneshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhoneshopApplication.class, args);
	}

}
