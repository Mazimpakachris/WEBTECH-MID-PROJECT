package phoneshop.phoneshop.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.registration.InMemoryClientRegistrationRepository;
import org.springframework.security.oauth2.core.AuthorizationGrantType;

@Configuration
class OAuth2ClientConfig {

    @Bean
    public ClientRegistrationRepository clientRegistrationRepository() {
        return new InMemoryClientRegistrationRepository(
                facebookClientRegistration(),
                googleClientRegistration() // Replacing Instagram with Google
        );
    }

    private ClientRegistration facebookClientRegistration() {
        return ClientRegistration.withRegistrationId("facebook")
                .clientId("your_facebook_client_id")
                .clientSecret("your_facebook_client_secret")
                .scope("public_profile", "email")
                .authorizationUri("https://www.facebook.com/dialog/oauth")
                .tokenUri("https://graph.facebook.com/oauth/access_token")
                .userInfoUri("https://graph.facebook.com/me?fields=id,name,email,picture")
                .redirectUri("{baseUrl}/login/oauth2/code/facebook")
                .clientName("Facebook")
                .authorizationGrantType(AuthorizationGrantType.AUTHORIZATION_CODE) // Set authorization grant type
                .build();
    }

    private ClientRegistration googleClientRegistration() {
        return ClientRegistration.withRegistrationId("google")
                .clientId("632375007911-c5ib81e4d3hfpnc79ph3hoalke7u4h92.apps.googleusercontent.com")
                .clientSecret("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")
                .scope("openid", "profile", "email") // Google OAuth scopes
                .authorizationUri("https://accounts.google.com/o/oauth2/auth")
                .tokenUri("https://oauth2.googleapis.com/token")
                .userInfoUri("https://www.googleapis.com/oauth2/v3/userinfo")
                .redirectUri("http://localhost:8081/index")
                .clientName("Google")
                .authorizationGrantType(AuthorizationGrantType.AUTHORIZATION_CODE) // Set authorization grant type
                .build();
    }
}
