package phoneshop.phoneshop.Controller;


import phoneshop.phoneshop.model.MyAppUser;
import phoneshop.phoneshop.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class AdminController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // Show the list of users
    @GetMapping("/adminUsers")
    public String listUsers(Model model) {
        List<MyAppUser> users = userRepository.findAll();  // Fetch all users
        model.addAttribute("users", users);  // Pass the list of users to the model
        return "adminUsers";  // Points to the Thymeleaf template "adminUsers.html"
    }

    // Show the add user form
    @GetMapping("/addUser")
    public String showAddUserForm(Model model) {
        model.addAttribute("user", new MyAppUser());
        return "addUserForm";  // Points to a Thymeleaf template "addUserForm.html"
    }

    // Handle form submission to add a new user
    @PostMapping("/addUser")
    public String addUser(@ModelAttribute("user") MyAppUser user) {
        user.setPassword(passwordEncoder.encode(user.getPassword())); // Use injected passwordEncoder directly
        userRepository.save(user); // Use injected userRepository directly
        return "redirect:/adminUsers";
    }

    // Show the edit user form
    @GetMapping("/editUser/{id}")
    public String showEditUserForm(@PathVariable Long id, Model model) {
        MyAppUser user = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid user Id:" + id));
        model.addAttribute("user", user);
        return "addUserForm";  // Reusing addUserForm.html for edit
    }

    // Handle form submission to edit a user
    @PostMapping("/editUser/{id}")
    public String editUser(@PathVariable Long id, @ModelAttribute("user") MyAppUser user) {
        MyAppUser existingUser = userRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid user Id:" + id));
        existingUser.setUsername(user.getUsername());
        existingUser.setEmail(user.getEmail());
        existingUser.setFullName(user.getFullName());
        existingUser.setDateOfBirth(user.getDateOfBirth());
        existingUser.setIdType(user.getIdType());
        existingUser.setIdNumber(user.getIdNumber());
        existingUser.setPhoneNumber(user.getPhoneNumber());

        // Only update the password if it's non-empty
        if (user.getPassword() != null && !user.getPassword().isEmpty()) {
            existingUser.setPassword(passwordEncoder.encode(user.getPassword()));
        }

        userRepository.save(existingUser);
        return "redirect:/adminUsers";
    }

    // Handle delete user request
    @PostMapping("/api/users/{id}/delete")
    public String deleteUser(@PathVariable Long id) {
        userRepository.deleteById(id);
        return "redirect:/adminUsers";
    }
}

