package phoneshop.phoneshop.Controller;


import phoneshop.phoneshop.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/forgotPassword")
    public String showForgotPasswordForm() {
        return "forgotPassword"; // Returns the forgot password view
    }

    @PostMapping("/resetPasswordRequest")
    public String processForgotPasswordRequest(String email) {
        userService.sendPasswordResetLink(email);
        return "redirect:/login?resetLinkSent"; // Redirect to login page with a success message
    }

    @GetMapping("/resetPassword")
    public String showResetPasswordForm(Model model) {
        // This method should validate the reset token sent to the email
        return "resetPassword"; // Returns the reset password view
    }

    @PostMapping("/resetPassword")
    public String resetPassword(String newPassword, String confirmPassword) {
        userService.resetPassword(newPassword, confirmPassword);
        return "redirect:/login?passwordReset"; // Redirect to login page with a success message
    }
}

