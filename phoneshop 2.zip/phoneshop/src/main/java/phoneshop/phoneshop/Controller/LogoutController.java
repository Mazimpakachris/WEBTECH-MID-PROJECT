package phoneshop.phoneshop.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class LogoutController {

    @GetMapping("/logout")
    public String logout(RedirectAttributes redirectAttributes) {
        // You can add any logout logic here, like invalidating sessions
        // Redirecting to the login page with a success message
        redirectAttributes.addFlashAttribute("logoutMessage", "You have been logged out successfully.");
        return "redirect:/login"; // Redirect to login page after logout
    }
}
