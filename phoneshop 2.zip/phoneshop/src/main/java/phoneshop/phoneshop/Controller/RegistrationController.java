package phoneshop.phoneshop.Controller;


import phoneshop.phoneshop.model.MyAppUser;
import phoneshop.phoneshop.model.Role;
import phoneshop.phoneshop.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashSet;
import java.util.Set;

@RestController
public class RegistrationController {

    private static final Role ROLE_ADMIN = Role.ROLE_ADMIN; // Define ROLE_ADMIN
    @Autowired
    private UserRepository myAppUserRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostMapping(value = "/req/signup", consumes = "application/json")
    public MyAppUser createUser(@RequestBody MyAppUser user) {
        // Encode the password before saving
        user.setPassword(passwordEncoder.encode(user.getPassword()));

        // Prepare a set to hold assigned roles
        Set<Role> assignedRoles = new HashSet<>();

        // Check if the user selected a role
        if (user.getRoles() != null && !user.getRoles().isEmpty()) {
            for (Role role : user.getRoles()) {
                if (role.equals(ROLE_ADMIN)) {
                    assignedRoles.add(ROLE_ADMIN); // Assign admin role
                } else {
                    assignedRoles.add(Role.ROLE_USER); // Assign default user role
                }
            }
        } else {
            // Assign default role if none is selected
            assignedRoles.add(Role.ROLE_USER);
        }

        user.setRoles(assignedRoles);

        // Save the user with their roles
        return myAppUserRepository.save(user); // This should work without issues now
    }
}

