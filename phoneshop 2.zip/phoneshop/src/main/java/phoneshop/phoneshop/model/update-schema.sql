CREATE TABLE my_app_user
(
    id            BIGINT NULL,
    username      VARCHAR(255) NULL,
    email         VARCHAR(255) NULL,
    full_name     VARCHAR(255) NULL,
    date_of_birth datetime NULL,
    id_type       VARCHAR(255) NULL,
    id_number     VARCHAR(255) NULL,
    password      VARCHAR(255) NULL,
    phone_number  VARCHAR(255) NULL,
    roles         SMALLINT NULL
);