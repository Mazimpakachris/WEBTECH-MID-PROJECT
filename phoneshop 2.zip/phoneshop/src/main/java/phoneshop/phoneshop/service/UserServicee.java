package phoneshop.phoneshop.service;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import phoneshop.phoneshop.model.MyAppUser;
import phoneshop.phoneshop.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

@Service
public class UserServicee {

    // Assume you have a UserRepository to fetch users
    @Autowired
    private UserRepository userRepository;

    public ByteArrayInputStream generatePdf() throws IOException {
        Document document = new Document();
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            PdfWriter.getInstance(document, outputStream);
            document.open();
            document.add(new Paragraph("List of Users"));

            // Create a table and add headers
            PdfPTable table = new PdfPTable(4); // Adjust columns as needed
            table.addCell("Username");
            table.addCell("Email");
            table.addCell("Full Name");
            table.addCell("Phone");

            // Fetch the list of users from the repository
            List<MyAppUser> users = userRepository.findAll();
            for (MyAppUser user : users) {
                table.addCell(user.getUsername());
                table.addCell(user.getEmail());
                table.addCell(user.getFullName());
                table.addCell(user.getPhoneNumber());
            }

            document.add(table);
        } catch (DocumentException e) {
            e.printStackTrace();
        } finally {
            document.close();
        }
        return new ByteArrayInputStream(outputStream.toByteArray());
    }
}
